package net.gzz.online_class.service.impl;


import net.gzz.online_class.config.CacheKeyManager;
import net.gzz.online_class.model.entity.Video;
import net.gzz.online_class.model.entity.VideoBanner;
import net.gzz.online_class.mapper.VideoMapper;
import net.gzz.online_class.service.VideoService;
import net.gzz.online_class.utils.BaseCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class VideoServiceImpl implements VideoService {

    @Autowired
    private VideoMapper videoMapper;
    @Autowired
    private BaseCache baseCache;


    @Override
    public List<Video> listVideo() {

        try{
         Object cacheObj = baseCache.getTenMinuteCache().get(CacheKeyManager.INDEX_VIDEO_LIST,()->{
                List<Video>  videoList  = videoMapper.listVideo();
                System.out.println("从数据库中找视频详情");
                return videoList;
            });
            if(cacheObj instanceof  List){
                List<Video>  videoList = (List<Video>)cacheObj;
                return  videoList;
            }

        }catch (Exception e){
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public List<VideoBanner> listBanner() {

       /* try{
            //先根据key去找 找到之后放入object对象中
          Object cacheObj =  baseCache.getTenMinuteCache().get(CacheKeyManager.INDEX_BANNER_KEY, ()->{*/

                List<VideoBanner> bannerList  = videoMapper.listVideoBanner();
                System.out.println("从数据库里面找轮播图列表");
                return bannerList;
         /*   });
          //防止误拿到其他缓存 判断是否是子类型
         if(cacheObj instanceof List){
             List<VideoBanner> bannerList = (List<VideoBanner>) cacheObj;
             return bannerList;
         }

        }catch (Exception e){
            e.printStackTrace();
        }

        return null;*/
    }

    @Override
    public Video findDetailById(int videoId) {
        //因为有百分号 需要把videoId的格式转换
        String videoCacheKey = String.format(CacheKeyManager.VIDEO_DETAIL,videoId);
        try{
            Object cacheObj = baseCache.getOneHourCache().get( videoCacheKey,()->{
                // 需要使用mybatis关联复杂查询  三表查询
                Video video =videoMapper. findDetailById(videoId);
                return video;

            });

            if(cacheObj instanceof Video){
                Video video =(Video)cacheObj;
                return video;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
