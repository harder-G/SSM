package net.gzz.online_class.config;

import net.gzz.online_class.interceptor.CorsInterceptor;
import net.gzz.online_class.interceptor.LoginInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 拦截器配置
 * 不用权限可以访问url  /api/v1/pub/
 * 要登录可以访问url /api/v1/pri/
 */
//配置才会被扫描
@Configuration
public class InterceptorConfig implements WebMvcConfigurer {

    @Bean
    LoginInterceptor loginInterceptor(){
        return new LoginInterceptor();
    }

    @Bean
    CorsInterceptor corsInterceptor() {
        return  new CorsInterceptor();
    }



    @Override
    public void addInterceptors(InterceptorRegistry registry) {

        /**
         * 拦截全部路径，这个跨域需要放在最上面
         */
        registry.addInterceptor(corsInterceptor()).addPathPatterns("/**");


        //添加拦截器 点名那些路径不拦截  先登录注册 注册的部分不拦截 无法登陆就无法token
        registry.addInterceptor(loginInterceptor()).addPathPatterns("/api/v1/pri/*/*/**")
                //不拦截那些路径  斜杠一定要加
                .excludePathPatterns("/api/v1/pri/user/login","/api/v1/pri/user/register");
        //调用父类
        WebMvcConfigurer.super.addInterceptors(registry);



    }
}
