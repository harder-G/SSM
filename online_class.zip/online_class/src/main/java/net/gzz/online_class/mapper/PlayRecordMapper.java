package net.gzz.online_class.mapper;

import net.gzz.online_class.model.entity.Episode;
import net.gzz.online_class.model.entity.PlayRecord;
import org.apache.ibatis.annotations.Param;

public interface PlayRecordMapper {

    int saveRecord(PlayRecord playRecord);


}
