package net.gzz.online_class.service;


import net.gzz.online_class.model.entity.Video;
import net.gzz.online_class.model.entity.VideoBanner;

import java.util.List;

public interface VideoService {

   List<Video> listVideo();

   List<VideoBanner> listBanner();


   Video findDetailById(int videoId);
}
