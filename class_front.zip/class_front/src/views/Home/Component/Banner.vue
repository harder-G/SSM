<template>
  <div>
    <cube-slide :data="banners">
        <!--banner是一个数组 item是当前的项 index是索引-->
      <cube-slide-item v-for="(item, index) in banners" :key="index">
          <!--轮播图有url和img-->
        <a :href="item.url">
          <img :src="item.img" style="width:100%" />
        </a>
      </cube-slide-item>
    </cube-slide>
  </div>
</template>



<script>
export default {
  //获取⽗组件传递过来的值
  props: {
    banners: {
      type: Array,
      required: true
    }
  }
};
</script>


<style lang="scss" scoped>
</style>