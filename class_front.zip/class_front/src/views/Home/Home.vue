<template>
  <div>
    <!-- 轮播图组件  把Data中的数据传递给banners子组件-->
     <home-banner :banners="banners"> </home-banner> 
    <!-- 视频列表组件 -->
     <!-- <video-list :courselist="courselist"></video-list>  -->
     <video-list :videoList="videoList"></video-list> 

    <!-- 底部导航栏组件 -->
    <common-footer></common-footer>
  </div>
</template>

<script>
import HomeBanner from "./Component/Banner";
import VideoList from "./Component/VideoList";
//@根目录
import CommonFooter from "@/components/CommonFooter";
import { getBanner, getVideoList } from "@/api/getData.js";
export default {
  //注册组件
  components: {
    HomeBanner,
    VideoList,
    CommonFooter
  },
  //声明数据源 把method方法中的banners赋值到data中的banner中
  data() {
    return {
      banners: [],
      videoList: []
    };
  },
  //定义⽅法
  methods: {
    // 获取轮播图数据  result本身会包括一层data
    async getBannerData() {
      try {
        const result = await getBanner();
        console.log(result);
        if (result.data.code == 0) {
          this.banners = result.data.data;
        }
      } catch (error) {
        console.lo(error)
      }
    },
    //获取视频列表  getVList方法不能和import导入的方法同名
    async getVList() {
      try {
        const result = await getVideoList();
         console.log(result);
        if (result.data.code == 0) {
          this.videoList = result.data.data;
        }
      } catch (error) {
        console.lo(error)
      }
    }
  },
  mounted() {
    //⻚⾯渲染完成调⽤⽅法获取数据
    this.getBannerData();
    this.getVList();
  }
};
</script>

<style lang="scss" scoped>
</style>