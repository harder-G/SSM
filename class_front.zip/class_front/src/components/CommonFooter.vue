<template>
  <div class="tab">
    <!--事件 监察方法changHandler-->
    <cube-tab-bar v-model="selectedLabelSlots" @click="changHandler">
      <!--插槽-->
      <cube-tab
        v-for="(item) in tabs"
        :icon="item.icon"
        :label="item.label"
        :key="item.path"
        :value="item.path"
      ></cube-tab>
    </cube-tab-bar>
  </div>
</template>

<script>
export default {
  data() {
    return {
      selectedLabelSlots: "/",
      //选项卡的数组 path对应的路由映射
      tabs: [
        {
          label: "⾸⻚",
          icon: "cubeic-home",
          path: "/",
        },
        {
          label: "我的订单",
          icon: "cubeic-like",
          path: "/order",
        },
        {
          label: "个⼈中⼼",
          icon: "cubeic-person",
          //path: "/personal"
          path: "/register"
        },
      ],
    };
  },
  methods: {
    changHandler(path) {
      //this.$route.path是当前路径   path和当前浏览器的路径是否一样
      if (path !== this.$route.path) {
        //path传进去 进行路由跳转
        this.$router.push(path);
      }
    },
  },
  created() {
    //默认路由选择器，⽐如刷新⻚⾯，需要重新进到当前路由
    this.selectedLabelSlots = this.$route.path;
  },
};
</script>

<!--SCSS是⼀种CSS预处理语⾔, scoped 是指这个scss样式 只作⽤于当前组件-->
<style lang="scss" scoped>
.tab {
  position: fixed;
  bottom: 0;
  z-index: 999;
  background-color: #fff;
  width: 100%;
  border-top: 1px solid rgba($color: #000000, $alpha: 0.1);
}
.cube-tab_active {
  color: #3bb149;
}
</style>