import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)
export default new Vuex.Store({
state: {
  //取值时取到尾部 加空串不会有问题
token: localStorage.getItem("token") ||''
},
//同步修改state⾥⾯的值
mutations: {
SET_TOKEN:(state, token)=>{
state.token = token
}
},
//异步调⽤mutations⾥⾯的⽅法
//contxt.commit 利⽤上下⽂触发mutations某个⽅法
// vue代码⾥⾯ this.$store.dispatch触发action⾥⾯的定义的⽅法
actions: {
setToken(context,token){
context.commit('SET_TOKEN',token)
},
clearToken(context){
context.commit('SET_TOKEN','')
}
},
modules: {
}
})